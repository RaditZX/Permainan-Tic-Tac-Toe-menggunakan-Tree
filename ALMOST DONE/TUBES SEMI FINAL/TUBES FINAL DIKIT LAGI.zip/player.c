#include "player.h"

void entryMove(char board[3][3], char current_player, char *playerName)
{

    int col,row;
    printf("%s turn (row): ", playerName);
    if (scanf("%d", &row) != 1 || row < 0 || row >= 3)
    {
        printf("Invalid input for row. Try again.\n");
        while (getchar() != '\n')
            ; // Clear input buffer
    }

    printf("%s turn (col): ", playerName);
    if (scanf("%d", &col) != 1 || col < 0 || col >= 3)
    {
        printf("Invalid input for column. Try again.\n");
        while (getchar() != '\n')
            ; // Clear input buffer
    }

    if (!is_valid_move(board, row, col))
    {
        printf("Invalid move. Try again.\n");
    }

    board[row][col] = current_player;
}
boolean is_valid_move(char board[3][3], int row, int col)
{
    boolean valid_row = (row >= 0 && row < 3);
    boolean valid_col = (col >= 0 && col < 3);
    boolean empty_cell = (board[row][col] == EMPTY_CELL);

    return (valid_row && valid_col && empty_cell);
}
